# -*- coding: utf-8 -*-
"""
Created on Thu Jul  4 11:42:49 2019

@author: Emma
"""

if __name__ == "__main__":


    from model_with_policy import borg_ebola
    
    import numpy as np
    
    from ema_workbench import (Model, IntegerParameter, RealParameter, ReplicatorModel,
                               TimeSeriesOutcome, ScalarOutcome, ArrayOutcome, Policy, Scenario)
    
    #model = Model('Ebola', function=borg_ebola)
    model = ReplicatorModel('Ebola', function=borg_ebola)
    
    model.replications = 150
    
    model.outcomes = [ScalarOutcome('mean effectiveness', ScalarOutcome.MINIMIZE, function=np.mean, 
                                   variable_name='Effectiveness'),
                      ScalarOutcome('mean time until containment', ScalarOutcome.MINIMIZE, function = np.mean, 
                                   variable_name='Time until Containment'),
                      ScalarOutcome('mean difference in met demand', ScalarOutcome.MINIMIZE, function = np.mean, 
                                   variable_name='Difference in Met Demand'),
                      ScalarOutcome('mean difference in arrival time', ScalarOutcome.MINIMIZE, function = np.mean, 
                                   variable_name='Difference in Arrival Time'),
                      ScalarOutcome('mean cost per death prevented', ScalarOutcome.MINIMIZE, function = np.mean, 
                                   variable_name='Cost per Death Prevented'),
                      ArrayOutcome('Uncertainty over Time', variable_name='Uncertainty over Time'),
                      ArrayOutcome('Decision Types over Time', variable_name='Decision Types'),
                      ArrayOutcome('Chosen Regions', variable_name='Chosen Regions')]
    
                
    model.uncertainties = [IntegerParameter('I4', 1, 8),
                           IntegerParameter('I14', 20, 35),
                           IntegerParameter('I15', 25, 40),
                           RealParameter('beta_i', 0.1, 0.5),
                           RealParameter('travel_rate', 0.04, 0.1)]
    
    
    model.levers = [RealParameter('c1', -1.0, 1.0),
                   RealParameter('c2', -1.0, 1.0),
                   RealParameter('r1', 0.000001, 1.0),
                   RealParameter('r2', 0.000001, 1.0),
                   RealParameter('w', 0, 1.0)]
                    
    
    reference = Scenario('reference', I4=3, I14=25, I15=32, beta_i=0.32, travel_rate=0.05) 
    
    from ema_workbench import SequentialEvaluator, MultiprocessingEvaluator, ema_logging
    
    from ema_workbench.em_framework.optimization import (HyperVolume,
                                                         EpsilonProgress)
    
    ema_logging.log_to_stderr(ema_logging.INFO)
    
    convergence_metrics = [HyperVolume(minimum=[-1,0,0,0,0], maximum=[0,26, 3, 2000, 1000000]),
                           EpsilonProgress()]
    
    
    #with SequentialEvaluator(model) as evaluator:
    with MultiprocessingEvaluator(model) as evaluator:
        results, convergence = evaluator.optimize(nfe=25000, searchover='levers',
                                     convergence=convergence_metrics,
                                     epsilons=[0.02, 2, 0.02, 20, 100],
                                     reference=reference)
        
        
        
    import pandas as pd
    results.to_csv('optimization_results')
    convergence.to_csv('convergence')